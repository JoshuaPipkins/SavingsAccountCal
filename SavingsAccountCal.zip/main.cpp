#include <iostream>
using namespace std;
    int main(){
        cout<<"============================================\n";
        cout<<"\t         -- Details -- \n";
        cout<<"This program calculates the balance of a savings\n"; 
        cout<< "account at the end of a period of time.\n"<<endl; 
        cout<<"============================================\n";

        double annualInterest;          
        double balance;                 
        int months;                     
        double totalDeposit  = 0.0;     
        double totalWithdraw = 0.0;    
        double earnedInterest= 0.0;     
        double deposited;               
        double withdrawn;               

        cout<<"Please enter your annual interest rate,\n";
        cout<< "Annual interest: ";
        cin >>annualInterest;
        cout<<"--------------------------------------------\n";
        cout<<"Please enter the starting balance,\n";
        do{
            cout<<"Starting Balance: ";
            cin >>balance;
        }while(balance<0);
        cout<<"--------------------------------------------\n";
        cout<<"Please enter the number of months,\n";
        do{
            cout<<"Number of months: ";
            cin >>months;
        }while(months<0);
        cout<<"============================================\n";
        for(int month=1; month <= months; month++){
            
        
            cout<<"Enter the deposited value during month "<<endl;
            do{
                cout<<" Deposited value: ";
                cin >>deposited;
            }while(deposited<0);
            
            totalDeposit += deposited;
            balance += deposited;
            cout<<"--------------------------------------------\n";
            cout<<"Enter the withdrawn value during month\n "<<endl;
            do{
                cout<<" Withdrawn value: ";
                cin >>withdrawn;
            }while(withdrawn<0);
            break; 
            totalWithdraw += withdrawn;
            balance -= withdrawn;
            cout<<"============================================\n";
            if(balance < 0){
                cout<<"Sorry, the account has been closed due to\n";
                cout<<"the negative balance.\n";
                cout<<"============================================\n";
                break;
            
  
            } else {
                earnedInterest += (annualInterest/12) * balance;
                balance += (annualInterest/12) * balance;
            }
        }
        
        cout<<"Here are the results: \n";
        cout<<"The ending balance: "<<balance<<endl;
        cout<<"   Total deposited: "<< totalDeposit<<endl;
        cout<<" Total withdrawals: "<< totalWithdraw<<endl;
        cout<<"   Earned interest: "<< earnedInterest<<endl;
        return 0;
    }
    